import { Negative } from './negatives';

describe('Negative', () => {
  it('should create an instance', () => {
    expect(new Negative()).toBeTruthy();
  });
});
