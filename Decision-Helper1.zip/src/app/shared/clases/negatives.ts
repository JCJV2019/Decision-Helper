export class Negative {
  'id': string;
  'desc': string;
  'point': number;
}
