import { Positive } from './positives';

describe('Positive', () => {
  it('should create an instance', () => {
    expect(new Positive()).toBeTruthy();
  });
});
