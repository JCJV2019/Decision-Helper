export class Positive {
  'id': string;
  'desc': string;
  'point': number;
}
